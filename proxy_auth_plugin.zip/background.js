
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "la.residential.rayobyte.com",
                port: parseInt(8000)
              },
              bypassList: ["localhost"]
            }
          };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "farhanahmed1360_gmail_com",
                    password: "ipl3QJUiNxyf"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    